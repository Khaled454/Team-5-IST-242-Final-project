package edu.psu.abington.ist.ist242;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PartsTest {

    @Test
    void listParts() {
    }

    @Test
    void printPartsByCategory() {
    }

    @Test
    void addParts() {
    }

    @Test
    void removeParts() {
    }
}
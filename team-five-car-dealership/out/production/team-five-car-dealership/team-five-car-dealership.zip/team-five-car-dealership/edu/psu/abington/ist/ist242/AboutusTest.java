package edu.psu.abington.ist.ist242;

import static org.junit.jupiter.api.Assertions.*;

class AboutusTest {

    @org.junit.jupiter.api.Test
    void printAboutus() {
    }
}
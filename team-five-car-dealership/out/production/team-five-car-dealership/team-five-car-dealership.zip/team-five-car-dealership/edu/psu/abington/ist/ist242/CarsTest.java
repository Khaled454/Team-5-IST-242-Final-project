package edu.psu.abington.ist.ist242;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CarsTest {

    @Test
    void listCars() {
    }

    @Test
    void printCarByMakeModelYearAndMiles() {
    }

    @Test
    void addCars() {
    }

    @Test
    void removeCars() {
    }
}
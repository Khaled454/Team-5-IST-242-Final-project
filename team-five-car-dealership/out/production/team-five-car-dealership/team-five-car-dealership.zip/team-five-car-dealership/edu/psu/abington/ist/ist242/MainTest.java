package edu.psu.abington.ist.ist242;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    void main() {
    }

    @Test
    void getAction() {
    }

    @Test
    void searchType() {
    }

    @Test
    void getType() {
    }

    @Test
    void getManageInventory() {
    }
}
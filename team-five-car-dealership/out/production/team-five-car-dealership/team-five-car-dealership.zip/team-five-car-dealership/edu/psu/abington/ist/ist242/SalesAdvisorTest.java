package edu.psu.abington.ist.ist242;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SalesAdvisorTest {

    @Test
    void contactSalesAdvisor() {
        
    }
}
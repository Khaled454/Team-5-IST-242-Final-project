package edu.psu.abington.ist.ist242;

public class Aboutus {

    /**
     * Print Car Dealership Information to the Command Line
     * @author  Brianna Price
     * @since   2020-06-27
     * @version 1.0
     */
    public static void printAboutus() {
        System.out.println("Welcome to the Car Dealership \n" + "(484)-577-7389 \n" + "cardealership@buyacar.com \n" + "321 Dealership Road \n" + "Philly, PA 82017");
    }
}

# G5-dealershipApp
Project Objective: create a web application that addresses the business requirements of a small- to medium-sized car dealership; datastore; arrays.
